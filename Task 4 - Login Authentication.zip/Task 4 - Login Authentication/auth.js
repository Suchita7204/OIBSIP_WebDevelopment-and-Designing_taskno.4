// Register
const registerForm = document.getElementById('registerForm');
if (registerForm) {
  registerForm.addEventListener('submit', function (e) {
    e.preventDefault();
    const username = document.getElementById('regUser').value;
    const password = document.getElementById('regPass').value;

    const users = JSON.parse(localStorage.getItem('users') || '{}');

    if (users[username]) {
      alert('Username already exists!');
    } else {
      users[username] = password;
      localStorage.setItem('users', JSON.stringify(users));
      alert('Registration successful! Please login.');
      window.location.href = "index.html";
    }
  });
}

// Login
const loginForm = document.getElementById('loginForm');
if (loginForm) {
  loginForm.addEventListener('submit', function (e) {
    e.preventDefault();
    const username = document.getElementById('loginUser').value;
    const password = document.getElementById('loginPass').value;

    const users = JSON.parse(localStorage.getItem('users') || '{}');

    if (users[username] && users[username] === password) {
      localStorage.setItem('loggedInUser', username);
      window.location.href = "dashboard.html";
    } else {
      alert('Invalid credentials!');
    }
  });
}
